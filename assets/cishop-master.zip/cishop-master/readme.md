# CodeIgniter Online Shop Demo

Ini adalah contoh source code untuk aplikasi online shop menggunakan framework CodeIgniter 3. Source code ini adalah bahan pendukung untuk materi online course [Membangun Toko Online Menggunakan Framework CodeIgniter](https://www.codepolitan.com/learn/membangun-toko-online-menggunakan-framework-codeigniter) dari [CodePolitan](https://www.codepolitan.com/).

Demo aplikasi dapat dilihat pada url berikut: [cishopdemo.cloudapp.web.id](http://cishopdemo.cloudapp.web.id/)